package com.loozb.core.support.weixin.model;

/**
 * @author ShenHuaJie
 * @since 2017年2月3日 下午5:10:58
 */
public class KeFu {
	private String kf_account;
	private String nickname;
	private String password;

	public String getKf_account() {
		return kf_account;
	}

	public void setKf_account(String kf_account) {
		this.kf_account = kf_account;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
